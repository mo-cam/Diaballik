package model;

import diaballik.model.*;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;

import static diaballik.model.ChoiceColor.BLEU;
import static diaballik.model.ChoiceColor.ROUGE;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class TestGame {
    private Game game;
    private Human player1;
    private Human player2;
    AI ia;

    @Before
    public void initalize() {
        player1 = new Human("Morgane", BLEU);
        player2 = new Human("Isabelle", ROUGE);
        Strategy strat = new StrategyNoob();
        ia = new AI("IA",ROUGE,strat);
        game = new Game(player1, player2, new Board());
    }

    @Test
    public void testCreation() {
        assertNotNull(game);
    }

    @Test
    public void testBoard() {
        assertNotNull(game.getBoard());
    }

    @Test
    public void testPlayer1_1() {
        assertEquals(Human.class, game.getPlayer1().getClass());
    }

    @Test
    public void testPlayer1_2() {
        assertEquals("Morgane", game.getPlayer1().getName());
    }

    @Test
    public void testPlayer1_3() {
        assertEquals(BLEU, game.getPlayer1().getColor());
    }

    @Test
    public void testPlayer1_4() {
        assertEquals(player1, game.getPlayer1());
    }

    @Test
    public void testPlayer2_1() {
        assertEquals(Human.class, game.getPlayer2().getClass());
    }

    @Test
    public void testPlayer2_2() {
        assertEquals("Isabelle", game.getPlayer2().getName());
    }

    @Test
    public void testPlayer2_3() {
        assertEquals(ROUGE, game.getPlayer2().getColor());
    }

    @Test
    public void testPlayer2_4() {
        assertEquals(player2, game.getPlayer2());
    }

    @Test
    public void testPlayer2_5(){
        game.setPlayer2(ia);
        assertTrue(game.getPlayer2().getClass().equals(AI.class) && game.getPlayer2().getName().equals("IA")
                && game.getPlayer2().getColor().equals(ROUGE));
    }

    @Test
    public void testUndoCommand1() {
        assertNull(game.getUndoCommand());
    }

    @Test
    public void testUndoCommand2() {
        game.setUndoCommand(new ArrayList<Commande>());
        assertNotNull(game.getUndoCommand());
    }

    @Test
    public void testRedoCommand1() {
        assertNull(game.getRedoCommand());
    }

    @Test
    public void testRedoCommand2() {
        game.setRedoCommand(new ArrayList<Commande>());
        assertNotNull(game.getRedoCommand());
    }

    @Test
    public void testTurn1() {
        assertNull(game.getTurn());
    }

    @Test
    public void testTurn2() {
        Turn turn = new Turn(2);
        turn.setP1(player1);
        turn.setP2(player2);
        game.setTurn(turn);
        assertEquals(turn, game.getTurn());
    }

    @Test
    public void testWin1() {
        BuildNewGame buildNewGame = new BuildNewGame(0,"Isabelle","Morgane");
        // Initialement, la piece 7 est en [6][0]
        buildNewGame.getGame().getBoard().setValue(buildNewGame.getGame().getBoard().getList().get(7), 5, 1);
        buildNewGame.getGame().getBoard().setValue(null, 6, 0);
        // Initialement, la piece 3 est en [0][3] et possede la balle bleue
        buildNewGame.getGame().getBoard().setValue(buildNewGame.getGame().getBoard().getList().get(3), 6, 0);
        buildNewGame.getGame().getBoard().setValue(null, 0, 3);
        assertTrue(buildNewGame.getGame().win(buildNewGame.getGame().getPlayer1()));
    }

    @Test
    public void testWin2() {
        BuildNewGame buildNewGame = new BuildNewGame(0,"Isabelle","Morgane");
        // Initialement, la piece 1 est en [0][0]
        buildNewGame.getGame().getBoard().setValue(buildNewGame.getGame().getBoard().getList().get(1), 1, 1);
        buildNewGame.getGame().getBoard().setValue(null, 0, 0);
        // Initialement, la piece 10 est en [6][3] et possede la balle rouge
        buildNewGame.getGame().getBoard().setValue(buildNewGame.getGame().getBoard().getList().get(10), 0, 0);
        buildNewGame.getGame().getBoard().setValue(null, 6, 3);
        assertTrue(buildNewGame.getGame().win(buildNewGame.getGame().getPlayer2()));
    }

}
