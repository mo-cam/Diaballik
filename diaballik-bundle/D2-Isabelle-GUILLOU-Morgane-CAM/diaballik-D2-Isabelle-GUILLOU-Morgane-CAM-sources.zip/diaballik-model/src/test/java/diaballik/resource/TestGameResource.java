package diaballik.resource;

import com.github.hanleyt.JerseyExtension;
import diaballik.model.BuildNewGame;
import diaballik.model.Game;
import diaballik.serialization.DiabalikJacksonProvider;
import org.glassfish.jersey.jackson.JacksonFeature;
import org.glassfish.jersey.server.ResourceConfig;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.RegisterExtension;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.Application;
import javax.ws.rs.core.Response;
import java.io.IOException;
import java.net.URI;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class TestGameResource {
    @SuppressWarnings("unused")
    @RegisterExtension
    JerseyExtension jerseyExtension = new JerseyExtension(this::configureJersey);

    private Game gameTestPvP;

    private Application configureJersey() {
        return new ResourceConfig().
                register(GameResource.class).// GameResource.class).
                register(MyExceptionMapper.class).
                register(JacksonFeature.class).
                register(DiabalikJacksonProvider.class).
                property("jersey.config.server.tracing.type", "ALL");
    }

    @BeforeEach
    void setUp(final Client client, final URI baseUri) {
        BuildNewGame buildGamePvP = new BuildNewGame(0, "Isabelle", "Morgane");
        gameTestPvP = buildGamePvP.getGame();
    }

    @Test
    void testTemplate(final Client client, final URI baseUri) {
        client.register(JacksonFeature.class).register(DiabalikJacksonProvider.class);
    }

    @Test
    void testCreationGamePvP(final Client client, final URI baseUri) {
        client.register(JacksonFeature.class).register(DiabalikJacksonProvider.class);
        final Response response = client.target(baseUri).path("game/newGamePvP/0/Isabelle/Morgane").request().post(Entity.json(gameTestPvP));
        assertEquals(Response.Status.OK.getStatusCode(), response.getStatus());
    }

    @Test
    void testSaveGame(final Client client, final URI baseUri) throws IOException {
        client.register(JacksonFeature.class).register(DiabalikJacksonProvider.class);
        // Comme on cree une "gameTestPvP", on doit donc ensuite pouvoir la sauvegarder
        Game game = client.target(baseUri).path("game/newGamePvP/0/Isabelle/Morgane").request().post(Entity.json(gameTestPvP)).readEntity(Game.class);
        Response response = client.target(baseUri).path("game/save/gameTestPvP").request().post(Entity.json(game));
        assertEquals(Response.Status.OK.getStatusCode(),response.getStatus());
    }

    @Test
    void testSaveError(final Client client, final URI baseUri) {
        client.register(JacksonFeature.class).register(DiabalikJacksonProvider.class);
        // Comme on ne cree pas la "gameTestPvP", on doit avoir une BAD_REQUEST comme retour
        final Response res = client.
                target(baseUri).
                path("game/save/gameTestPvP").
                request().
                post(Entity.text(""));

        assertEquals(Response.Status.BAD_REQUEST.getStatusCode(), res.getStatus());
    }

    @Test
    void testLoadGame(final Client client, final URI baseUri) {
        client.register(JacksonFeature.class).register(DiabalikJacksonProvider.class);
        // On cree la "gameTestPvP" puis on sauvegarde cette partie, on doit donc ensuite pouvoir la recuperer
        Game game = client.target(baseUri).path("game/newGamePvP/0/Isabelle/Morgane").request().post(Entity.json(gameTestPvP)).readEntity(Game.class);
        client.target(baseUri).path("game/save/gameTestPvP").request().post(Entity.json(game));
        Response response = client.target(baseUri).path("game/load/gameTestPvP").request().get();
        assertEquals(Response.Status.OK.getStatusCode(), response.getStatus());
    }

    @Test
    void testLoadError1(final Client client, final URI baseUri) {
        client.register(JacksonFeature.class).register(DiabalikJacksonProvider.class);
        // On ne cree pas la partie, donc rien n'a ete sauvegarde, on ne doit donc rien pouvoir recuperer
        final Response res = client.
                target(baseUri).
                path("game/load/erreur").
                request().
                get();

        assertEquals(Response.Status.BAD_REQUEST.getStatusCode(), res.getStatus());
    }

    @Test
    void testLoadError2(final Client client, final URI baseUri) {
        client.register(JacksonFeature.class).register(DiabalikJacksonProvider.class);
        // On cree la "gameTestPvP" mais on ne la sauvegarde pas,  on ne doit donc rien pouvoir recuperer
        client.target(baseUri).path("game/newGamePvP/0/Isabelle/Morgane").request().post(Entity.json(gameTestPvP));
        final Response res = client.target(baseUri).path("game/load/erreur").request().get();
        assertEquals(Response.Status.BAD_REQUEST.getStatusCode(), res.getStatus());
    }

	@Test
	void testReplayGame(final Client client, final URI baseUri) throws IOException {
		client.register(JacksonFeature.class).register(DiabalikJacksonProvider.class);
		Game game = client.target(baseUri).path("game/newGamePvP/0/Isabelle/Morgane").request().post(Entity.json(gameTestPvP)).readEntity(Game.class);
		client.target(baseUri).path("game/save/gameTestPvP").request().post(Entity.json(game));
		final Response res = client.target(baseUri).path("game/replay/gameTestPvP").request().get();
		Assertions.assertEquals(Response.Status.OK.getStatusCode(), res.getStatus());
	}

	@Test
	void testUndoNotFound(final Client client, final URI baseUri) {
		client.register(JacksonFeature.class).register(DiabalikJacksonProvider.class);
		final Response res = client.target(baseUri).path("game/replay/undo").request().put(Entity.text(""));
		assertEquals(Response.Status.BAD_REQUEST.getStatusCode(), res.getStatus());
	}


	@Test
	void testPreviousReplaySuccess(final Client client, final URI baseUri) {
		client.register(JacksonFeature.class).register(DiabalikJacksonProvider.class);
		Game game = client.target(baseUri).path("game/newGamePvP/0/Isabelle/Morgane").request().post(Entity.json(gameTestPvP)).readEntity(Game.class);
		client.target(baseUri).path("game/player/move/false/0/1/1/1").request().put(Entity.json(game));
		client.target(baseUri).path("game/save/gameTestPvP").request().post(Entity.json(game));
		client.target(baseUri).path("game/replay/gameTestPvP").request().get();

		final Response resNext = client.
				target(baseUri).
				path("game/replay/redo").
				request().
				put(Entity.text(""));

		final Response res = client.
				target(baseUri).
				path("game/replay/undo").
				request().
				put(Entity.text(""));

		Assertions.assertEquals(Response.Status.OK.getStatusCode(), res.getStatus());
	}

	@Test
	void testRedoNotFound(final Client client, final URI baseUri) {
		client.register(JacksonFeature.class).register(DiabalikJacksonProvider.class);
		final Response res = client.target(baseUri).path("game/replay/redo").request().put(Entity.text(""));
		assertEquals(Response.Status.BAD_REQUEST.getStatusCode(), res.getStatus());
	}


	@Test
	void testDeplacementPiece(final Client client, final URI baseUri) {
		client.register(JacksonFeature.class).register(DiabalikJacksonProvider.class);
		Game game = client.target(baseUri).path("game/newGamePvP/0/Isabelle/Morgane").request().post(Entity.json(gameTestPvP)).readEntity(Game.class);
		// On deplace la piece rouge initialement en [6][1] jusqu'en [5][1] (vertical)
		final Response res = client.target(baseUri).path("game/player/move/false/6/1/5/1").request().put(Entity.json(game));

		assertEquals(Response.Status.OK.getStatusCode(), res.getStatus());
	}

	@Test
	void testDeplacementBall(final Client client, final URI baseUri) {
		client.register(JacksonFeature.class).register(DiabalikJacksonProvider.class);
		Game game = client.target(baseUri).path("game/newGamePvP/0/Isabelle/Morgane").request().post(Entity.json(gameTestPvP)).readEntity(Game.class);
		// On deplace la piece rouge initialement en [6][1] jusqu'en [4][1], on peut ainsi deplacer la balle (diagonal)
		client.target(baseUri).path("game/player/move/false/6/1/5/1").request().put(Entity.json(game));
		client.target(baseUri).path("game/player/move/false/5/1/4/1").request().put(Entity.json(game));
		final Response res = client.target(baseUri).path("game/player/move/true/6/3/4/1").request().put(Entity.json(game));

		assertEquals(Response.Status.OK.getStatusCode(), res.getStatus());
	}

}
