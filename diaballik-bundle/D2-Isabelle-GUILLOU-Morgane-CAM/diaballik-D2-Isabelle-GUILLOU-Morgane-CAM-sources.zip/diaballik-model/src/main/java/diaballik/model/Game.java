package diaballik.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

import diaballik.serialization.DiabalikJacksonProvider;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.IntStream;


/**
 * Classe representant une partie
 */
@JsonIdentityInfo(generator = ObjectIdGenerators.IntSequenceGenerator.class)
public class Game {
	/**
	 * Attributs
	 */
	// Le plateau de jeu de la partie
	private Board board;
	// J1 sera le joueur jouant avec les pieces bleues
	private Human j1;
	// J2 sera donc le joueur celui jouant avec les pieces rouges
	// Si nbPlayer == 1, j2 est de type AI. Si nbPlayer == 2, j2 est de type Human.
	private Player j2;
	// Sauvegarde des commandes effectuees que l'on va pouvoir annuler
	private List<Commande> undoCommand;
	// Sauvegarde des commandes annulees que l'on va pouvoir jouer
	private List<Commande> redoCommand;
	// Le tour en cours
	@JsonProperty("turn")
	protected Turn turn;
	// Liste des parties sauvegardees
	@JsonProperty("listSavedGame")
	protected List<Game> listSavedGame;

	/**
	 * Constructeur
	 */
	@JsonCreator
	public Game(@JsonProperty("j1") final Human j1, @JsonProperty("j2") final Player j2, @JsonProperty("board") final Board board) {
		this.j1 = j1;
		this.j2 = j2;
		this.board = board;
	}

	/**
	 * Getter du plateau de jeu de la partie
	 *
	 * @return le plateau de jeu de la partie
	 */
	public Board getBoard() {
		return board;
	}

	/**
	 * Setter d'un board a notre partie
	 *
	 * @param b le plateau de jeu que l'on va utiliser pour la partie
	 */
	public void setBoard(final Board b) {
		this.board = b;
	}

	/**
	 * Getter du premier joueur de la partie
	 *
	 * @return le premier joueur
	 */
	public Human getPlayer1() {
		return j1;
	}

	/**
	 * Setter du premier joueur de la partie
	 *
	 * @param p1 le joueur auquel on va associe la place de numero 1
	 */
	public void setPlayer1(final Human p1) {
		this.j1 = p1;
	}

	/**
	 * Getter du second joueur de la partie
	 *
	 * @return le second joueur
	 */
	public Player getPlayer2() {
		return j2;
	}

	/**
	 * Setter du second joueur de la partie
	 *
	 * @param p2 le joueur auquel on va associe la place de numero 2
	 */
	public void setPlayer2(final Player p2) {
		this.j2 = p2;
	}

	/**
	 * Getter de la liste de commandes que l'on va pouvoir annuler
	 *
	 * @return la liste des commandes effectuees
	 */
	public List<Commande> getUndoCommand() {
		return undoCommand;
	}

	/**
	 * Setter de la liste de commande que l'on va pouvoir annuler
	 *
	 * @param undoCommand la liste de commande que l'on va pouvoir annuler
	 */
	public void setUndoCommand(final List<Commande> undoCommand) {
		this.undoCommand = undoCommand;
	}

	/**
	 * Getter de la liste de commandes que l'on va pouvoir rejouer
	 *
	 * @return la liste de commandes annulees
	 */
	public List<Commande> getRedoCommand() {
		return redoCommand;
	}

	/**
	 * Setter de la liste de commandes que l'on va pouvoir rejouer
	 *
	 * @param redoCommand la liste des commandes que l'on va pouvoir rejouer
	 */
	public void setRedoCommand(final List<Commande> redoCommand) {
		this.redoCommand = redoCommand;
	}

	/**
	 * Getter du tour en cours de la partie
	 *
	 * @return le tour en cours de la partie
	 */
	@JsonIgnore
	public Turn getTurn() {
		return turn;
	}

	/**
	 * Setter d'un tour : on associe un tour a notre partie
	 *
	 * @param turn le tour en cours de la partie
	 */
	public void setTurn(final Turn turn) {
		this.turn = turn;
	}

	/**
	 * Getter de la liste de parties sauvegardees
	 *
	 * @return la liste des parties que l'on a sauvegarde
	 */
	public List<Game> getListSavedGame() {
		return listSavedGame;
	}

	/**
	 * @param games la liste des parties que l'on a deja sauvegarde
	 */
	public void setListSavedGame(final List<Game> games) {
		this.listSavedGame = games;
	}

	/**
	 * Verifie si la piece de j possedant la balle est sur la ligne adverse
	 *
	 * @param j Le joueur j a-t-il gagne ?
	 * @return si le joueur j a gagne
	 */
	public boolean win(final Player j) {
		final AtomicBoolean res = new AtomicBoolean(false);
		// On essaie de savoir si le joueur 1 a gagne
		if (j1.equals(j)) {
			final Piece pballJ1 = board.getList().stream().filter(piece -> piece.getHasBall() &&
					piece.getColor().equals(ChoiceColor.BLEU)).findFirst().get();
			IntStream.rangeClosed(0, 6).forEach(i -> {
				if (board.getValue(6, i) != null && board.getValue(6, i).equals(pballJ1)) {
					res.set(true);
				}
			});
			// On essaie de savoir si le joueur 2 a gagne
		} else if (j2.equals(j)) {
			final Piece pballJ2 = board.getList().stream().filter(piece -> piece.getHasBall() &&
					piece.getColor().equals(ChoiceColor.ROUGE)).findFirst().get();
			IntStream.rangeClosed(0, 6).forEach(i -> {
				if (board.getValue(0, i) != null && board.getValue(0, i).equals(pballJ2)) {
					res.set(true);
				}
			});
		}
		return res.get();
	}

	/**
	 * Sauvegarder la partie dans un fichier
	 */
	public void save(final String nomFichier) throws IOException {
		new DiabalikJacksonProvider().getMapper().writeValue(new File("./" + nomFichier + ".json"), this);
		listSavedGame.add(this);
	}

	/**
	 * Chargement d'une partie sauvegardee
	 *
	 * @param nomFichier le nom du fichier dans lequel on a sauvegarde la partie que l'on souhaite reprendre
	 */
	public Optional<Game> load(final String nomFichier) throws IOException {
		final Game gameLoaded = new DiabalikJacksonProvider().getMapper().readValue(new File("./" + nomFichier + ".json"), Game.class);
		listSavedGame.remove(gameLoaded);
		return Optional.of(gameLoaded);
	}

	/**
	 * Annule la derniere action faite (presente dans la liste undoCommand)
	 */
	public void undoCommande() {
		final Commande commandeAAnnuler = undoCommand.get(undoCommand.size() - 1);
		commandeAAnnuler.undo(this);
		redoCommand.add(0, commandeAAnnuler);
		undoCommand.remove(commandeAAnnuler);
	}

	/**
	 * Rejoue la derniere action annulee (presente dans la liste redoCommand)
	 */
	public void redoCommande() {
		final Commande commandeARejouer = redoCommand.get(redoCommand.size() - 1);
		commandeARejouer.redo(this);
		undoCommand.add(0, commandeARejouer);
		redoCommand.remove(commandeARejouer);
	}

	/**
	 * Verifie que deux parties sont egales
	 *
	 * @param o la partie que l'on compare a la notre
	 * @return vrai si les deux parties sont egales, faux sinon
	 */
	@Override
	public boolean equals(final Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		final Game game = (Game) o;
		return Objects.equals(board, game.board) &&
				Objects.equals(j1, game.j1) &&
				Objects.equals(j2, game.j2) &&
				Objects.equals(undoCommand, game.undoCommand) &&
				Objects.equals(redoCommand, game.redoCommand) &&
				Objects.equals(turn, game.turn) &&
				Objects.equals(listSavedGame, game.listSavedGame);
	}

	/**
	 * Hash notre partie
	 *
	 * @return le hash code de notre partie
	 */
	@Override
	public int hashCode() {
		return Objects.hash(board, j1, j2, undoCommand, redoCommand, turn, listSavedGame);
	}
}
