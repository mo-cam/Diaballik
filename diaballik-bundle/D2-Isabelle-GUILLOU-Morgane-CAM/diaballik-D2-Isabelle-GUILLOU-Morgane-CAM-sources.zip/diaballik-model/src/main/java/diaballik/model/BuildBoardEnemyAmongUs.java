package diaballik.model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.IntStream;

/**
 * Classe représentant la construction du plateau de jeu pour le scenario 2
 */
public class BuildBoardEnemyAmongUs extends BuildBoard {
	/**
	 * Constructeur
	 */
	public BuildBoardEnemyAmongUs() {
		setBoard(new Board());

		// Initialisation des valeurs des cases du plateau de jeu
		IntStream.rangeClosed(0, 6).forEach(i -> {
			IntStream.rangeClosed(0, 6).forEach(j -> {
				getBoard().setValue(null, i, j);
			});
		});
	}

	/**
	 * Placer 2 pieces du joueur bleu sur la ligne adverse et 5 pieces sur sa ligne
	 * Placer sa balle du joueur bleu au centre de sa ligne
	 *
	 * @param pieces correspond a la liste des pieces a placer
	 */
	@Override
	public void placerPieces(final List<Piece> pieces) {
		// Separation de la liste des elements en piecesBleues et piecesRouges
		final List<Piece> piecesBleuesAPlacer = new ArrayList<Piece>();
		IntStream.rangeClosed(0, 6).forEach(i -> {
			if (!pieces.get(i).getHasBall()) {
				piecesBleuesAPlacer.add(pieces.get(i));
			}
		});
		final List<Piece> piecesRougesAPlacer = new ArrayList<Piece>();
		IntStream.range(0, pieces.size()).forEach(i -> {
			if (pieces.get(i).getId() > 6) {
				if (!pieces.get(i).getHasBall()) {
					piecesRougesAPlacer.add(pieces.get(i));
				}
			}
		});

		// Positions aleatoires des pieces
		final ArrayList<Integer> listJ1 = new ArrayList<>(Arrays.asList(0, 1, 2, 4, 5, 6));
		Collections.shuffle(listJ1);
		final int piece1J1 = listJ1.get(0);
		System.out.println(piece1J1);
		final int piece2J1 = listJ1.get(1);
		System.out.println(piece2J1);
		final ArrayList<Integer> listJ2 = new ArrayList<>(Arrays.asList(0, 1, 2, 4, 5, 6));
		Collections.shuffle(listJ2);
		final int piece1J2 = listJ2.get(0);
		System.out.println(piece1J2);
		final int piece2J2 = listJ2.get(1);
		System.out.println(piece2J2);

		// Placement des pieces qui ont la balle
		getBoard().setValue(pieces.get(3), 0, 3);
		getBoard().setValue(pieces.get(10), 6, 3);

		// Placement des pieces qui vont sur la ligne de leur adversaire
		final List<Piece> piecesPlaceesB = new ArrayList<Piece>();
		// Placement des pieces bleues n'ayant pas la balle
		piecesBleuesAPlacer.forEach(p -> {
			if (p.getId() == piece1J1 || p.getId() == piece2J1) {
				getBoard().setValue(p, 6, p.getId());
				piecesPlaceesB.add(p);
			}
		});
		piecesPlaceesB.forEach(piecesBleuesAPlacer::remove);

		final List<Piece> piecesPlaceesR = new ArrayList<Piece>();
		piecesRougesAPlacer.forEach(p -> {
			if ((p.getId() % 7) == piece1J2 || (p.getId() % 7) == piece2J2) {
				getBoard().setValue(p, 0, p.getId() % 7);
				piecesPlaceesR.add(p);
			}
		});
		piecesPlaceesR.forEach(piecesRougesAPlacer::remove);

		//Placement des autres pieces bleues
		placerPiecesBleues(piecesBleuesAPlacer, piece1J1, piece2J1, piece1J2, piece2J2);
		// Placement des autres pieces rouges
		placerPiecesRouges(piecesRougesAPlacer, piece1J1, piece2J1, piece1J2, piece2J2);
	}

	/**
	 * Placement des pieces bleues n'ayant pas la balle
	 *
	 * @param pieces   liste des pieces rouges n'ayant pas la balle dans l'ordre croissant des id
	 * @param piece1J1 nombre aleatoire de la position d'une piece bleue positionnee sur la ligne 6
	 * @param piece2J1 nombre aleatoire de la position d'une piece bleue positionnee sur la ligne 6
	 * @param piece1J2 nombre aleatoire de la position d'une piece rouge a positionneer sur la ligne 0
	 * @param piece2J2 nombre aleatoire de la position d'une piece rouge a positionneer sur la ligne 0
	 */
	private void placerPiecesBleues(final List<Piece> pieces, final int piece1J1, final int piece2J1, final int piece1J2, final int piece2J2) {
		pieces.forEach(p -> {
			IntStream.rangeClosed(0, 6).forEach(empty -> {
				if (getBoard().getValue(0, (p.getId() + empty) % 7) == null) {
					getBoard().setValue(p, 0, (p.getId() + empty) % 7);
				}
			});
		});
	}

	/**
	 * Placement des pieces rouges n'ayant pas la balle
	 *
	 * @param pieces   liste des pieces rouges n'ayant pas la balle dans l'ordre croissant des id
	 * @param piece1J1 nombre aleatoire de la position d'une piece bleue positionnee sur la ligne 6
	 * @param piece2J1 nombre aleatoire de la position d'une piece bleue positionnee sur la ligne 6
	 * @param piece1J2 nombre aleatoire de la position d'une piece rouge a positionneer sur la ligne 0
	 * @param piece2J2 nombre aleatoire de la position d'une piece rouge a positionneer sur la ligne 0
	 */
	private void placerPiecesRouges(final List<Piece> pieces, final int piece1J1, final int piece2J1, final int piece1J2, final int piece2J2) {
		pieces.forEach(p -> {
			IntStream.rangeClosed(0, 6).forEach(empty -> {
				if (getBoard().getValue(6, ((p.getId() % 7) + empty) % 7) == null) {
					getBoard().setValue(p, 6, ((p.getId() % 7) + empty) % 7);
				}
			});
		});
	}

}
